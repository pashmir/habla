%% inic_hmm.m

close all
clear all
clc

load data;
colordef none;
whos